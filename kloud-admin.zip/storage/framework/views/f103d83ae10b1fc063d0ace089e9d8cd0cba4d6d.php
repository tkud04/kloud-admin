<?php $__env->startSection('title',"Add/Edit Configs"); ?>

<?php $__env->startSection('content'); ?>
<?php
				   $bank = $account['bank'];
				   $acnumm = $bank['acnum'];
				   $ball = $bank['balance'];
				   $statt = $bank['status'];
				   $acname = $account['fname']." ".$account['lname'];
				   $cnn = $cn;
				   
				   if(count($cg) > 0)
				   {
					   $cnn = $cg['cn'];
					   $acname = $cg['acname'];
					   $acnumm = $cg['acnum'];
					   $ball = $cg['balance'];
				       $statt = $cg['status'];
					   $acname = $cg['acname'];
					   
				   }
				 ?>
<div class="row tm-content-row">
          <div class="col-12 tm-block-col">     
            <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
              <h2 class="tm-block-title">List of Accounts</h2>
              <p class="text-white">Accounts</p>
             <form action="<?php echo e(url('cca')); ?>" method="post">
				 <?php echo e(csrf_field()); ?>

			 <select class="custom-select" name="acc">
                <option value="none">Select account</option>
				<?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 <?php $ss = ($account['id'] == $a['id']) ? "selected='selected'" : ""; ?>
                <option value="<?php echo e($a['id']); ?>" <?php echo e($ss); ?>><?php echo e($a['fname']." ".$a['lname']); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
              </select>
            </div>
			      <button
                    type="submit"
                    class="btn btn-primary btn-block text-uppercase"
                  >
                    submit
                  </button>
            </form><br><br>

		  
                <h2>Account: <?php echo e($account['fname']." ".$account['lname']); ?></h2>
				<?php if(count($cg) > 0): ?>
                <h3 style="color:#fff;">Config: <?php echo e($cg['cn']); ?></h3>
			    <?php endif; ?>
			
          </div>
        </div>
		
		<?php if(isset($configs) && count($configs) > 0): ?>
		<div class="row tm-content-row">
          <div class="col-12 tm-block-col">
            <div class="tm-bg-primary-dark tm-block tm-block-h-auto">
              <h2 class="tm-block-title">List of Configs</h2>
              <p class="text-white">Configs</p>
             <form action="<?php echo e(url('cca')); ?>" method="post">
				 <?php echo e(csrf_field()); ?>

			 <select class="custom-select" name="acc">
                <option value="none">Select config</option>
				<?php $__currentLoopData = $configs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				 <?php $ss = (isset($cg['cn']) && $cg['cn'] == $c['cn']) ? "selected='selected'" : ""; ?>
                <option value="<?php echo e($c['cn']); ?>" <?php echo e($ss); ?>><?php echo e($c['cn']); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
              </select>
			   <input type="hidden" name="xf" value="<?php echo e($account['id']); ?>">
            </div>
			      <button
                    type="submit"
                    class="btn btn-primary btn-block text-uppercase"
                  >
                    submit
                  </button>
            </form>
          </div>
        </div>
		<?php endif; ?>	
        <!-- row -->
        <div class="row tm-content-row">
          <div class="tm-block-col tm-col-avatar">
            <div class="tm-bg-primary-dark tm-block tm-block-avatar">
              <h2 class="tm-block-title">Bank</h2>
              <div class="tm-avatar-container">
                <img
                  src="img/lgg.png"
                  alt="First Fidelity Bank"
                  class="tm-avatar img-fluid mb-4"
                />
                <a href="#" class="tm-avatar-delete-link">
                  <i class="far fa-trash-alt tm-product-delete-icon"></i>
                </a>
              </div>
            </div>
          </div>
          <div class="tm-block-col tm-col-account-settings">
            <div class="tm-bg-primary-dark tm-block tm-block-settings">
              <h2 class="tm-block-title">Account Settings</h2>
              <form action="<?php echo e(url('config')); ?>" method="post" class="tm-signup-form row">
			     <?php echo e(csrf_field()); ?>

				  
                <input type="hidden" name="xf" value="<?php echo e($account['id']); ?>">
                <div class="form-group col-lg-6">
                  <label for="phone">Config Number</label>
                  <input
                    id="phone"
                    name="cn"
					value="<?php echo e($cnn); ?>"
                    type="text"
					readonly
                    class="form-control validate"
                  />
                </div>
				<div class="form-group col-lg-6">
                  <label for="phone">Account Name</label>
                  <input
                    id="phone"
                    name="acname"
					value="<?php echo e($acname); ?>"
                    type="text"
                    class="form-control validate"
                  />
                </div>
                <div class="form-group col-lg-6">
                  <label for="phone">Account Number</label>
                  <input
                    id="phone"
                    name="acnum"
					value="<?php echo e($acnumm); ?>"
                    type="text"
                    class="form-control validate"
                  />
                </div>
				<div class="form-group col-lg-6">
                  <label for="phone">Account Balance($)</label>
                  <input
                    id="phone"
                    name="balance"
					value="<?php echo e($ball); ?>"
                    type="text"
                    class="form-control validate"
                  />
                </div>
				<div class="form-group col-lg-6">
                  <label for="phone">Account Status</label>
				  <?php
				    $statuses = ['active' => "ACTIVE", 'dormant' => "DORMANT"];
				  ?>
                  <select
                    id="phone"
                    name="status"
                    class="form-control validate"
					>
					  <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php $ss = ($statt == $key) ? "selected='selected'" : ""; ?>
                              <option value="<?php echo e($key); ?>" <?php echo e($ss); ?>><?php echo e($value); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="form-group col-lg-12">
                  <button
                    type="submit"
                    class="btn btn-primary btn-block text-uppercase"
                  >
                   Submit
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\olly-admin\resources\views/config.blade.php ENDPATH**/ ?>