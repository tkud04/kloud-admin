	<!-- Page info -->
	<div class="page-top-info">
		<div class="container">
			<h4><?=$title?></h4>
			<div class="site-pagination">
				<a href="<?php echo e(url('/')); ?>">Home</a> /
				<a href="#"><?=$title?></a> 
			</div>
		</div>
	</div>
	<!-- Page info end --><?php /**PATH C:\bkupp\lokl\repo\kloud-new\resources\views/generic-banner.blade.php ENDPATH**/ ?>