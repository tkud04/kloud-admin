<?php $__env->startSection('title',"Deals"); ?>

<?php $__env->startSection('content'); ?>

            <!-- row -->
            <div class="row tm-content-row">
			
			   <div class="col-12 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block tm-block-taller tm-block-scroll">
                        <h2 class="tm-block-title">Deals List - View, Edit or Remove Deals</h2>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">SKU</th>
                                    <th scope="col">NAME</th>
                                    <th scope="col">RATING</th>
                                    <th scope="col">STATUS</th>                                    
                                    <th scope="col">ACTIONS</th>                                    
                                </tr>
                            </thead>
                            <tbody>
							  <?php $__currentLoopData = $deals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><b><?php echo e($d['sku']); ?></b></th>
                                    
                                    <td><b><?php echo e($d['name']); ?></b></td>
                                    <td><b>
									<?php for($u = 0; $u < $d['rating']; $u++): ?>
                            	     <i class="far fa-star text-primary"></i>
                                    <?php endfor; ?>
									</b></td>
                                    <td><b><?php echo e($d['status']); ?> </b></td>
                                    <td>
									<a href="<?php echo e(url('deal').'?sku='.$d['sku']); ?>" class="tm-product-delete-link"><i class="far fa-eye tm-product-delete-icon"></i></a>
									<a href="#" class="tm-product-delete-link"><i class="far fa-trash-alt tm-product-delete-icon"></i></a>
									</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\kloud-admin\resources\views/deals.blade.php ENDPATH**/ ?>