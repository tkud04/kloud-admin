
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie10 lt-ie9 lt-ie8 lt-ie7" lang="en"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie10 lt-ie9 lt-ie8" lang="en"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie10 lt-ie9" lang="en"> <![endif]-->
<!--[if IE 9]>         <html class="no-js lt-ie10 lt-ie9" lang="en"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en"><!--<![endif]--><head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <title>
      <?php echo $__env->yieldContent('title'); ?> | First Fidelity Bank
    </title>
  <meta name="description" content="First Fidelity Bank is a community bank located in Oklahoma and Arizona offering a wide variety of personal and business banking products and services">
  <meta name="keywords" content="first fidelity bank, bank, oklahoma, arizona, checking, savings, loans, southwest, small business, commercial, mortgage, auto, vehicle, car, insurance, plan, credit card, investments, mobile deposit, rewards, treasury services, security, careers, student, free atms, fdic, bill pay, mobile app">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="apple-mobile-web-app-title" content="First Fidelity Bank N.A.">
  <link rel="stylesheet" href="assets/css/style.css?v=ada2018">
  <link rel="stylesheet" href="assets/css/fonts.css?v=11242014">
  <!-- Favicon -->
    <link rel="icon" href="favicon.png">
  <script src="assets/js/jquery-3.2.1.min.js"></script>
  <script src="assets/js/helper.js"></script>
  <script type="text/javascript">
    (function () {
      "use strict";
      //$.support.cors=true;

      // once cached, the css file is stored on the client forever unless
      // the URL below is changed. Any change will invalidate the cache
      var css_href = 'assets/css/fonts.css?v=11242014';
      // a simple event handler wrapper
      function on(el, ev, callback) {
        if (el.addEventListener) {
          el.addEventListener(ev, callback, false);
        } else if (el.attachEvent) {
          el.attachEvent("on" + ev, callback);
        }
      }
      
      // if we have the fonts in localStorage or if we've cached them using the native batrowser cache
      if ((window.localStorage && localStorage.font_css_cache) || document.cookie.indexOf('font_css_cache') > -1){
        // just use the cached version
        injectFontsStylesheet();
      } else {
       // otherwise, don't block the loading of the page; wait until it's done.
        on(window, "load", injectFontsStylesheet);
      }
      
      // quick way to determine whether a css file has been cached locally
      function fileIsCached(href) {
        return window.localStorage && localStorage.font_css_cache && (localStorage.font_css_cache_file === href);
      }

      // time to get the actual css file
      function injectFontsStylesheet() {
       // if this is an older browser
        if (!window.localStorage || !window.XMLHttpRequest) {
          var stylesheet = document.createElement('link');
          stylesheet.href = css_href;
          stylesheet.rel = 'stylesheet';
          stylesheet.type = 'text/css';
          document.getElementsByTagName('head')[0].appendChild(stylesheet);
          // just use the native browser cache
          // this requires a good expires header on the server
          document.cookie = "font_css_cache";
        
        // if this isn't an old browser
        } else {

            // use the cached version if we already have it
          if (fileIsCached(css_href)) {
            
            injectRawStyle(localStorage.font_css_cache);
            // otherwise, load it with ajax
          } else {
            var request = createCORSRequest("GET", css_href);
            if (request){
                request.onreadystatechange = function () {
                  if (request.readyState === 4) {
                    // once we have the content, quickly inject the css rules
                    injectRawStyle(request.responseText);
                    // and cache the text content for further use
                    // notice that this overwrites anything that might have already been previously cached
                    localStorage.font_css_cache = request.responseText;
                    localStorage.font_css_cache_file = css_href;
                  }
                };
                request.send();
            }
          }
        }
      }

      function createCORSRequest(method, url){
          var xhr = new XMLHttpRequest();
          // Check if the XMLHttpRequest object has a "withCredentials" property.
          // "withCredentials" only exists on XMLHTTPRequest2 objects.
          if ("withCredentials" in xhr){
              xhr.open(method, url, true);
          // Otherwise, check if XDomainRequest.
          // XDomainRequest only exists in IE, and is IE's way of making CORS requests.
          } else if (typeof XDomainRequest != "undefined"){
              xhr = new XDomainRequest();
              xhr.open(method, url);
          } else {
              // Otherwise, CORS is not supported by the browser.
              xhr = null;
          }
          return xhr;
      }


      // this is the simple utitily that injects the cached or loaded css text
      function injectRawStyle(text) {
        var style = document.createElement('style');
        // cater for IE8 which doesn't support style.innerHTML
        style.setAttribute("type", "text/css");
        if (style.styleSheet) {
            style.styleSheet.cssText = text;
        } else {
            style.innerHTML = text;
        }
        document.getElementsByTagName('head')[0].appendChild(style);
      }

    }());
  </script>
  <meta name="apple-itunes-app" content="app-id=858697007">
  <meta name="google-play-app" content="app-id=com.fi7149.godough"><!--[if lt IE 9]> <script src="assets/js/html5shiv.min.js"></script> <![endif]-->
  

          <style>
.video-responsive{
    overflow:hidden;
    padding-bottom:56.25%;
    position:relative;
    height:0;
}
.video-responsive iframe{
    left:0;
    top:0;
    height:100%;
    width:100%;
    position:absolute;
}
</style>
        
</head>

  <body class="home">
    <a href="#main" class="hidden-compliance">Skip Navigation</a>
<div class="hidden-compliance">
    Documents in Portable Document Format (PDF) require Adobe Acrobat Reader 5.0 or higher to view, <a href="http://get.adobe.com/reader/" class="hidden-compliance external" title="External Link">download Adobe® Acrobat Reader</a>.
</div>

    <div id="wrapper">
      <div class="alert hidden-alert">
        <div class="container">
          <button type="button" class="close" data-dismiss="alert" id="alert-hide"><i class="icon-alert-close"><span class="hidden-compliance">Close alert</span></i></button>
          <div class="alert-text" data-content-block="alert" data-content="content" data-editable="editable">
                <div> </div>
          </div>
        </div>
      </div>
      <header class="header" role="banner">
        <div class="top-nav">
  <div class="container">
    <ul class="banno-menu menu-52610eb0-240f-11e5-ae62-005056a30020">
                       <li class="menu-external">
        <a href="https://ffb.getfeedback.com/r/k8TCxO68/" target="_blank">Survey</a>
        
      </li><li class="menu-internal">
        <a href="#">Locations</a>
        
      </li><li class="menu-internal">
        <a href="<?php echo e(url('contact')); ?>">Contact Us</a>
        
      </li><li class="menu-external">
        <a href="<?php echo e(url('about')); ?>">About Us</a>
        
      </li>
                     </ul>
  </div>
</div>
<div class="container">
  <a href="#" class="logo pull-left" title="First Fidelity Bank N.A., Oklahoma City, OK" itemprop="url" itemscope="" itemtype="http://schema.org/BankOrCreditUnion">
    <div class="logotype" itemprop="logo">
      <h1 class="hidden-compliance">First Fidelity Bank N.A.</h1>
    </div>
  </a>

  <div class="header-right">
    <div class="menu-expanders visible-phone">
      <div class="olb-mobile-toggle">
        <i class="icon-olb-open"><span class="hidden-compliance">Open online banking</span></i>
        <i class="icon-olb-close"><span class="hidden-compliance">Close online banking</span></i>
      </div>
      <a class="navicon-button mwa-menu" href="javascript:;">
        <div class="navicon"><span class="hidden-compliance">Menu icon</span></div>
      </a>
    </div>
    <div class="mobile-olb-container">
	<?php if(isset($user) && $user != null): ?>
	  <?php
        $displayName = $user->fname." ".$user->mname." ".$user->lname;
        if($user->mname == "") $displayName = $user->fname." ".$user->lname;
      ?>
	  <div class="olb-label">Welcome back, <?php echo e($displayName); ?></div>
	   <div class="olb-submit">
         <a href="<?php echo e(url('dashboard')); ?>" class="btn">Go to dashboard</a>
         <a href="<?php echo e(url('logout')); ?>" class="btn">Sign out</a>
       </div>
	 
  <?php else: ?>
      <div class="olb-container">
        <i class="icon-olb-lock"></i> <span>Online Banking</span>
        <form action="<?php echo e(url('login')); ?>" method="post" id="olb-login-mobile">
			<?php echo e(csrf_field()); ?>

          <div class="control-group">
            <label for="id-olb-mobile">Username:</label>
            <input type="text" id="id-olb-mobile" name="id" class="field">
          </div>
          <div class="control-group">
            <label for="pin-olb-mobile">Password:</label>
            <input type="password" id="pin-olb-mobile" name="pass" class="field" autocomplete="off">
          </div><!--           <button type="submit" class="btn btn-info">LOGIN</button> -->

          <input type="submit" name="Submit" class="btn btn-info" value="LOGIN TO ONLINE BANKING">
        </form>
        <div class="olb-links">
          <a href="#">Reset Password</a>
        </div>
      </div>
	  <?php endif; ?>
    </div>
    <nav class="navbar" role="navigation">
      <div class="navbar-inner">
        <div class="container">
          <div class="nav-container">
            <div class="pre-menu visible-phone">
              <div class="quicklinks">
                <div id="quicklinks-selector" class="selector">
                    <span>QUICK LINKS</span>
                    <div class="add-select"></div>
                  </div>
              </div>
              <div class="nav-search">
                <form class="navbar-search-form" action="<?php echo e(url('search')); ?>" method="GET">
                  <label for="search" class="hidden-compliance">Search site</label>
                  <input type="text" name="q" class="span2 search-query" required="required" placeholder="Search for" autocomplete="off" id="search">
                  <button type="submit" class="btn" id="sbutton"><i class="icon-search"><span class="hidden-compliance">Search button</span></i></button>
                </form>
              </div>
            </div>
            <ul class="banno-menu menu-3e2464b0-240f-11e5-ae62-005056a30020">
                       <li class="dropdown menu-internal">
        <a href="#bank" class="dropdown-toggle">Bank</a>
        <ul class="dropdown-menu">
            <li class="menu-internal">
        <a href="#bank/personal">Personal</a>
        
      </li><li class="menu-internal">
        <a href="#bank/small-business">Small Business</a>
        
      </li><li class="menu-internal">
        <a href="#bank/commercial">Commercial</a>
        
      </li>
          </ul>
      </li><li class="dropdown menu-internal">
        <a href="#borrow" class="dropdown-toggle">Borrow</a>
        <ul class="dropdown-menu">
            <li class="menu-internal">
        <a href="#borrow/personal">Personal</a>
        
      </li><li class="menu-internal">
        <a href="#mortgage">Mortgage</a>
        
      </li><li class="menu-internal">
        <a href="#borrow/small-business">Small Business</a>
        
      </li><li class="menu-internal">
        <a href="#borrow/commercial">Commercial</a>
        
      </li><li class="menu-external">
        <a href="https://ffb.truecar.com/main.html?referrer_id=ZFFBSTAC0002" target="_blank">Auto Center</a>
        
      </li>
          </ul>
      </li><li class="dropdown menu-internal">
        <a href="#invest" class="dropdown-toggle">Plan</a>
        <ul class="dropdown-menu">
            <li class="menu-external">
        <a href="http://www.ffb-fg.com/">First Fidelity Financial Group</a>
        
      </li><li class="menu-internal">
        <a href="#personalinsurance">Personal Insurance</a>
        
      </li><li class="menu-external">
        <a href="https://www.ffb.com/sbinsurancexpress">Commercial Insurance</a>
        
      </li><li class="menu-external">
        <a href="http://www.ffb-fg.com/resource-center/calculators">Insurance Calculators</a>
        
      </li><li class="menu-internal">
        <a href="#invest/plan">Plan</a>
        
      </li><li class="menu-internal">
        <a href="#education-center">Education Center</a>
        
      </li>
          </ul>
      </li>
                     </ul><!-- <div class="nav-search pull-right hidden-phone">
              <form class="navbar-search-form" action="#search" method="GET">
                <label for="searchdesktop" class="hidden-compliance">Search</label>
                <input type="text" name="q" class="span2 search-query" required="required" placeholder="Search for" autocomplete="off" id="searchdesktop">
                <button type="submit" class="btn" id="sbuttonmobile"><i class="icon-search"><span class="hidden-compliance">Search icon</span></i></button>
              </form>
            </div> -->
            
            <div class="olb-desktop-container"><!-- <i class="icon-olb-lock"></i> <span>Online Banking</span> -->
  <?php if(isset($user) && $user != null): ?>
	  <?php
        $displayName = $user->fname." ".$user->mname." ".$user->lname;
        if($user->mname == "") $displayName = $user->fname." ".$user->lname;
      ?>
	  <div class="olb-label">Welcome back, <?php echo e($displayName); ?></div>
	   <div class="olb-submit">
         <a href="<?php echo e(url('dashboard')); ?>" class="btn">Go to dashboard</a>
         <a href="<?php echo e(url('logout')); ?>" class="btn">Sign out</a>
       </div>
	 
  <?php else: ?>
  <form action="<?php echo e(url('login')); ?>" method="post" id="olb-login-desktop" autocomplete="off">
    <?php echo e(csrf_field()); ?>

    <div class="olb-header">
      <label for="id-olb-desktop"><span class="hidden-compliance">Online Banking </span><div class="olb-label">Username:</div></label>
      <input type="text" id="id-olb-desktop" name="id" class="field" autocomplete="off">
      <span class="icon-olb-lock-desktop"></span><!-- <i class="icon-olb-lock"></i> -->
    </div>
    <div class="olb-header">
      <label for="pin-olb-desktop"><span class="hidden-compliance">Online Banking </span><div class="olb-label">Password:</div></label>
      <input type="password" id="pin-olb-desktop" name="pass" class="field" autocomplete="off">
    </div><!-- <button type="submit" class="btn btn-info">LOGIN</button> -->
    <div class="olb-submit">
      <input type="submit" name="Submit" class="btn" value="LOGIN">
    </div>
  </form>
    <div class="olb-desktop-links">
	 <a href="#">Reset Password ⟩</a>
    </div><!-- keep
  <div class="search-icon"><a href="#exampleModal"><img src="assets/img/search.png"></a></div> --><!-- trigger search modal -->
  <?php endif; ?>

<div class="search-icon">
  <button type="button" class="btnSearch" data-toggle="modal" data-target="#searchModal"><span class="hidden-compliance">Search</span></button>
</div>
</div><!-- search modal content -->

            
<div class="modal fade" data-backdrop="false" id="searchModal" tabindex="-1" role="dialog" aria-labelledby="searchLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title hidden-compliance" id="searchLabel">Search Modal</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <button type="button" class="btnSearch" data-toggle="modal" data-target="#searchModal"><span class="hidden-compliance">Search</span></button>
        <div class="nav-search pull-right hidden-phone">
          <form class="navbar-search-form" action="<?php echo e(url('search')); ?>" method="GET">
            <label for="searchdesktop" class="hidden-compliance">Search</label>
            <input type="text" name="q" class="span2 search-query" required="required" placeholder="SEARCH..." autocomplete="off" id="searchdesktop"><!--<button type="submit" class="btn" id="sbuttonmobile"><i class="icon-search"><span class="hidden-compliance">Search icon</span></i></button> -->
            
              <input type="submit" name="Submit" class="btn btn-search" value="GO">
          </form>
        </div>
      </div>
    </div>
  </div>
</div><!-- end Modal -->


          </div>
        </div>
      </div>
    </nav>
  </div>
</div>

      </header>
      
   <!--------- Session notifications-------------->
        	<?php
               $pop = ""; $val = "";
               
               if(isset($signals))
               {
                  foreach($signals['okays'] as $key => $value)
                  {
                    if(session()->has($key))
                    {
                  	$pop = $key; $val = session()->get($key);
                    }
                 }
              }
              
             ?> 

                 <?php if($pop != "" && $val != ""): ?>
                   <?php echo $__env->make('session-status',['pop' => $pop, 'val' => $val], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 <?php endif; ?>
        	<!--------- Input errors -------------->
                    <?php if(count($errors) > 0): ?>
                          <?php echo $__env->make('input-errors', ['errors'=>$errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <?php endif; ?> 
		  
  <?php echo $__env->yieldContent('content'); ?>

<div class="back-to-top">
  <a id="top"><i class="icon-top">Back To Top</i></a>              
</div>
<footer class="footer" role="contentinfo">
  <div class="container">
    <div class="footer-nav">
      <ul class="banno-menu menu-4e83fb90-240f-11e5-ae62-005056a30020">
                       <li class="dropdown menu-group">
        <span role="link" aria-expanded="false" class="group-item" tabindex="0">1st Row</span>
        <ul class="dropdown-menu">
            <li class="menu-internal">
        <a href="#report-lost/stolen-card">Report Lost/Stolen Card</a>
        
      </li><li class="menu-external">
        <a href="https://orderpoint.deluxe.com/personal-checks/welcome.htm" target="_blank">Order Personal Checks</a>
        
      </li><li class="menu-external">
        <a href="https://www.deluxeforms.com/brp.cfm?brpcode=611" target="_blank">Order Business Checks</a>
        
      </li><li class="menu-internal">
        <a href="#bank/free-atms-faq">Free ATMs Worldwide</a>
        
      </li>
          </ul>
      </li><li class="dropdown menu-group">
        <span role="link" aria-expanded="false" class="group-item" tabindex="0">2nd Row</span>
        <ul class="dropdown-menu">
            <li class="menu-external">
        <a href="https://www.ffb.com/loanpayments">Make a Loan Payment</a>
        
      </li><li class="menu-internal">
        <a href="#more-banking-products">More Banking Products</a>
        
      </li><li class="menu-external">
        <a href="https://www.ffb.com/education-center">Information Security</a>
        
      </li>
          </ul>
      </li><li class="dropdown menu-group">
        <span role="link" aria-expanded="false" class="group-item" tabindex="0">3rd Row</span>
        <ul class="dropdown-menu">
            <li class="menu-internal">
        <a href="#disclosures">Disclosures and Notices</a>
        
      </li><li class="menu-internal">
        <a href="#careers">Career Opportunities</a>
        
      </li><li class="menu-internal">
        <a href="#members-login">FFB Employee Portal</a>
        
      </li>
          </ul>
      </li><li class="dropdown menu-group">
        <span role="link" aria-expanded="false" class="group-item" tabindex="0">4th Row</span>
        <ul class="dropdown-menu">
            <li class="menu-internal">
        <a href="#invest/student-center">Student Center</a>
        
      </li><li class="menu-internal">
        <a href="#calculator/calc-menu">Calculators</a>
        
      </li><li class="menu-internal">
        <a href="#education-center">Education Center</a>
        
      </li><li class="menu-external">
        <a href="https://cameronenterprises.com/" target="_blank">Cameron Enterprises</a>
        
      </li>
          </ul>
      </li>
                     </ul>
    </div>
    <div class="pull-right footer-right-top">
      <div class="social">
        <a href="https://www.facebook.com/bankffb"><i class="icon-facebook">Facebook</i></a>
        <a href="https://twitter.com/bankffb"><i class="icon-twitter">Twitter</i></a>
        <a href="https://www.linkedin.com/company/bankffb"><i class="icon-linkedin">LinkedIn</i></a>
        <a href="https://www.youtube.com/channel/UChL1gN6siNL7n8rk2bmoZEw"><i class="icon-youtube">YouTube</i></a>
      </div>
      <div class="compliance">
        <a href="http://portal.hud.gov/hudportal/HUD"><img class="ehl" alt="Equal Housing Lender" src="assets/img/ehl.png" srcset="assets/img/ehl.png 1x, assets/img/ehl-2x.png 2x"></a>
        <a href="https://www.fdic.gov/"><img class="fdic" alt="Member FDIC" src="assets/img/fdic.png" srcset="assets/img/fdic.png 1x, assets/img/fdic-2x.png 2x"></a>
      </div>
    </div>
    <div class="pull-right footer-right-bottom">
      <div class="slogan">We go where you go.</div>
    </div>
  </div>
  <div class="livechat-fixed">
    <img id="liveagent_button_online_5731R000000H45j" style="display: none; border: 0px none; cursor: pointer" onclick="liveagent.startChat('5731R000000H45j')" src="https://ffb.secure.force.com/resource/1554305981000/FFBLogoedChatOnline"><img id="liveagent_button_offline_5731R000000H45j" style="display: none; border: 0px none; " src="https://ffb.secure.force.com/resource/1554306021000/FFBLogoedChatOffline"> 
  </div>
</footer>
      </div>

    </div>

    
<script src="assets/js/script.js"></script>

<script type="text/javascript">
 	$(window).on('load',function() {$.smartbanner({ daysHidden: 0, daysReminder: 0, title:'FFB Mobile', icon: "apple-touch-icon-57x57.png" }) });
 </script>

 <script type="text/javascript">
 (function (serve, h, s) {
 window.kernel = window.kernel || function () { (window.kernel.q = window.kernel.q || []).push(arguments); };
 h = document.getElementsByTagName("head")[0]; s = document.createElement("script"); s.src = serve+"#kernel.js"; s.async = 1; h.appendChild(s);
 })("https://kernel-serve.banno.com");
 kernel("create", "bd22c266-ec46-4d92-b47b-118400004213");
 kernel("visit");
 kernel("associate", "olb-login", "id");
 </script>


 <script type="text/javascript"> 
 	if (!window._laq) { window._laq = []; } 
 		window._laq.push(function(){liveagent.showWhenOnline('5731R000000H45j', document.getElementById('liveagent_button_online_5731R000000H45j')); 
 		liveagent.showWhenOffline('5731R000000H45j', document.getElementById('liveagent_button_offline_5731R000000H45j')); 
	});
</script> 


 <script type="text/javascript" src="https://c.la1-c1-ph2.salesforceliveagent.com/content/g/js/45.0/deployment.js"></script> 

 <script type="text/javascript"> 
 	liveagent.init('https://d.la1-c1-ph2.salesforceliveagent.com/chat', '5721R000000H35B', '00D36000000I9vH'); 
 </script> s









    <script>
      kernel("serve", {"id":"hero","w":1500,"h":700},{"id":"poster","w":270,"h":285},{"id":"poster2","w":270,"h":285},{"id":"poster3","w":270,"h":285},{"id":"poster4","w":270,"h":285},{"id":"sub1","w":1170,"h":240},{"id":"sub2","w":1170,"h":240});
    </script>


    <script type="text/javascript">
      if (!window._laq) { window._laq = []; }
      window._laq.push(function(){liveagent.showWhenOnline('57336000000PS6y', document.getElementById('liveagent_button_online_57336000000PS6y'));
      liveagent.showWhenOffline('57336000000PS6y', document.getElementById('liveagent_button_offline_57336000000PS6y'));
      });
    </script>


  

<script src="assets/target/disclaimers.js" id="disclaimerscript" defer="defer" proceed="Proceed" cancel="Cancel"></script>
          
        
            </body></html><?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/layout.blade.php ENDPATH**/ ?>