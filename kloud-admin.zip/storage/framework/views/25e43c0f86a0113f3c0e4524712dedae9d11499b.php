<?php $__env->startSection('title',$title); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('generic-banner',['title' => $title], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Contact section -->
	<section class="contact-section">
		<div class="container">
			<div class="row">
			    <div class="col-lg-12 mx-auto text-center">
                     <iframe  src="https://www.vtpass.com/" frameBorder='0'  style='margin: 0px; padding: 0px; border: 0px; width:100%; height: 600px; background-color: #fafafa;overflow:scroll'></iframe>
                </div>
			</div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\kloud-new\resources\views/airtime.blade.php ENDPATH**/ ?>