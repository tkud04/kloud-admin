<?php $__env->startSection('title',"Home Page"); ?>

<?php $__env->startSection('content'); ?>
<div class="main-wrapper">
        <div id="main" role="main">
          <div class="flexslider loading">
            <ul class="slides">
              <li>
                <div data-content-block="hero1" class="content" data-content="content" data-editable="editable">
                      <div><a href="#fraud-alerts" data-link-id="#fraud-alerts" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="" src="assets/files/9JEYGA4w/Fraud Alerts Hero2.png" image-id="9JEYGA4w"></a></div>
                </div>
              </li>
              <li>
                <div data-content-block="hero3" class="content img" data-content="content" data-editable="editable">
                      <div><a href="#awards" data-link-id="#awards" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="Forbes' Best Bank in Okalahoma" src="assets/files/LzgACsDy/Forbes Home Page Hero.png" image-id="LzgACsDy"></a></div>
                </div>
              </li>
              <li>
                <div data-content-block="hero5" class="content img" data-content="content" data-editable="editable">
                      <div><a href="#app" data-link-id="#app" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="" src="assets/files/3rfHquNE/GoBankFFB Coming Soon Hero.png" image-id="3rfHquNE"></a></div>
                </div>
              </li>
            </ul>
          </div>
          <div class="container">
            <div class="desktop-olb-container">

            </div>
          </div>
        </div><!--Slider Icons Section-->






        <div class="container thumbnail">
              <div class="thumbnail-section-header">
                <div data-content-block="header2" data-content="content" data-editable="editable" class="content">
                        <h2>You May be Interested in...</h2>
                  </div>
              </div>
              <div class="thumbnail-slider slider">

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon1bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="#personal-checking" data-link-id="#personal-checking" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="checkbook and pen icon" src="assets/content/icon-checkbook.png" image-id="RYY4qJeO"></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon1btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="#personal-checking" data-link-id="#personal-checking" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Checking ›</a></h3>
                     </div>
                  </div>
                </div>

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon2bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="#personal-savings" data-link-id="#personal-savings" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="combination safe icon" src="assets/content/icon-safe.png" image-id="CqeIBvcd"></a></div>
                      </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon2btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="#personal-savings" data-link-id="#personal-savings" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Savings ›</a></h3>
                    </div>
                  </div>
                </div>

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon3bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="#commercial" data-link-id="#commercial" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="storefront icon" src="assets/content/icon-cashManagement.png" image-id="ZhkXEtTz"></a></div>
                       </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon3btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="#bank/commercial" data-link-id="#bank/commercial" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Business ›</a></h3>
                  </div>
                  </div>
                </div>

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon4bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="#borrow/auto-loans" data-link-id="#borrow/auto-loans" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="car key icon" src="assets/content/Key Icon2.png" image-id="aBLjOcUT"></a></div>
                     </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon4btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="#borrow/auto-loans" data-link-id="#borrow/auto-loans" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Auto Loans ›</a></h3>
                   </div>
                  </div>
                </div>

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon5bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="#education-center" data-link-id="#education-center" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="umbrella icon" src="assets/content/icon-umbrella.png" image-id="Whgrsrkp"></a></div>
                    </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon5btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="#education-center" data-link-id="#education-center" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Education ›</a></h3>
                   </div>
                  </div>
                </div>

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon6bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="#borrow/personal" data-link-id="#borrow/personal" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="a house with a dollar sign icon" src="assets/content/icon-house.png" image-id="x3LIUcLf"></a></div>
                    </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon6btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="#borrow/personal" data-link-id="#borrow/personal" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Home Loans ›</a></h3>
                  </div>
                  </div>
                </div>

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon7bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="http://www.ffb-fg.com/" data-link-id="" data-link-type-id="url" class="" data-disclaimer-id="null" target="_self"><img alt="egg in a nest with a dollar sign icon" src="assets/content/icon-invest.png" image-id="HxDhegYk"></a></div>
                       </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon7btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="http://www.ffb-fg.com/" data-link-id="" data-link-type-id="url" class="" data-disclaimer-id="null" target="_self">Investments ›</a></h3>
                  </div>
                  </div>
                </div>

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon8bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="#borrow/credit-card" data-link-id="#borrow/credit-card" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="credit cards icon" src="assets/content/icon-cards.png" image-id="EWSyR15A"></a></div>
                    </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon8btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="#borrow/credit-card" data-link-id="#borrow/credit-card" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Credit Card ›</a></h3>
                  </div>
                  </div>
                </div>

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon9bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="#mobiledeposit" data-link-id="#mobiledeposit" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="mobile tablet and cell phone icon" src="assets/content/icon-mobileBanking.png" image-id="qhtbeuiA"></a></div>
                    </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon9btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="#mobiledeposit" data-link-id="#mobiledeposit" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Mobile Deposit ›</a></h3>
                  </div>
                  </div>
                </div>

                <div class="slide">
                  <div class="thumbnail-image">
                    <div class="zoom">
                      <div data-content-block="icon10bimg" data-content="content" data-editable="editable" class="content">
                        <div><a href="#rewards" data-link-id="#rewards" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="present or gift icon" src="assets/content/icon-rewards.png" image-id="Oz2h2YbO"></a></div>
                    </div>
                    </div>
                  </div>
                  <div class="thumbnail-text">
                    <div data-content-block="icon10btxt" data-content="content" data-editable="editable" class="content">
                        <h3><a href="#rewards" data-link-id="#rewards" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Rewards ›</a></h3>
                  </div>
                  </div>
                </div>
              </div>
          </div><!--End Slider Icons Section--><!--Banner Wrapper Section-->




        <div class="bannerWrapper">
          <div class="bannerImage">
            <div data-content-block="bannerimg" data-content="content" data-editable="editable" class="content">
            <div><img alt="three section banner with each section containing a couple doing various activities" src="assets/content/HP blue banner.png" image-id="BnmrYFYt"></div>
            </div>
          </div>
          <div class="bannerText container">
          <div data-content-block="bannertxt" data-content="content" data-editable="editable" class="content">
          <h2>FFB Rewards! <br></h2>
<p>With First Fidelity Bank, we reward you for your everyday purchases. Earn points to hundreds of rewards by using First Fidelity Bank's Visa Debit Card or Credit Card. Click to learn more.</p>
<p><a target="_self" data-disclaimer-id="null" class="btn btn-warning" data-link-type-id="url" data-link-id="" href="#rewards">FFB Rewards</a></p>
          </div>
          </div>
        </div><!--End Banner Wrapper Section--><!--Features Section--><!--Feature One Section-->




        <div class="container featuresRow">


            <div data-content-block="feature1img" data-content="content" data-editable="editable" class="content">
            <div class="featuresImages"><a href="#aboutus" data-link-id="#aboutus" data-link-type-id="page" class="" data-disclaimer-id="null" target="_blank" rel="noopener"><img alt="" src="https://banno.com:443/a/assets/api/institutions/7027/assets/b79cd100-59ae-11e9-be4c-02427c8671ff" image-id="b79cd100-59ae-11e9-be4c-02427c8671ff"></a></div>
<div class="featuresText">
<h3>We Go Where You Go</h3>
<p><a href="#aboutus" class="" title="WGWYG">Whether at home, work or anywhere in between, we go where you go</a> <br></p>
<p><a href="#aboutus" class="" title="WGWYG">Learn More <span style="color: #222222; font-family: Menlo, monospace; font-size: 11px; line-height: normal; white-space: pre-wrap;">»</span></a></p>
</div>
            </div>


        </div><!--End Feature One Section--><!--Feature Two Section-->


        <div class="container featuresRow">

            <div data-content-block="feature2img" data-content="content" data-editable="editable" class="content">
            <div class="featuresImages"><a href="#bank/free-atms-faq" data-link-id="#bank/free-atms-faq" data-link-type-id="page" class="" data-disclaimer-id="null" target="_blank" rel="noopener"><img alt="" src="https://banno.com:443/a/assets/api/institutions/7027/assets/bb037ba0-59ae-11e9-be4c-02427c8671ff" image-id="bb037ba0-59ae-11e9-be4c-02427c8671ff"></a></div>
<div class="featuresText">
<h3>Free ATMs Worldwide</h3>
<p><a href="#bank/free-atms-faq" class="">No matter where life takes you, never pay an ATM fee</a> <br></p>
<p><a href="#bank/free-atms-faq" class="">Learn More <span style="color: #222222; font-family: Menlo, monospace; font-size: 11px; line-height: normal; white-space: pre-wrap;">»</span></a></p>
</div>
            </div>

        </div><!--End Feature Two Section--><!--End Features Section-->



        <div class="container">
            <hr>
        </div><!--Text Only Features Section-->



        <div class="container textOnly">
        <div data-content-block="blurb" data-content="content" data-editable="editable" class="content">
          <h3>Treasury Services</h3>
<p style="text-align: left;" class="big">First Fidelity offers a variety of Treasury Services that facilitate efficient cash management for businesses of all sizes. Click on the link for more information and watch the video below. </p>
<p style="text-align: center;" class="big"><a href="#bank/treasury-services" data-link-id="#bank/treasury-services" data-link-type-id="page" class="btn btn-warning" data-disclaimer-id="null" target="_self">Learn More</a></p>
<p style="text-align: left;" class="big"><br></p>
<div class="video-responsive"><iframe src="https://www.youtube.com/embed/-WBb7-rS9MA" width="640" height="360" frameborder="0" allowfullscreen="allowfullscreen"></iframe></div>
<h3><br></h3>
<h3 style="text-align: center;">Guardian Services <br></h3>
<p style="text-align: left;">Identity theft is the fastest growing crime in the world and we want to help keep you safe. Make your life more secure by adding Guardian to personal checking or savings account. </p>
<p><a target="_self" data-disclaimer-id="null" class="btn btn-warning" data-link-type-id="url" data-link-id="" href="#guardian">Learn More</a></p>
        </div>
        </div><!--End Text Only Features Section-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/index.blade.php ENDPATH**/ ?>