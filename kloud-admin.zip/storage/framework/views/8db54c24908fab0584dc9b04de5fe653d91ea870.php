<?php $__env->startSection('title',"Enroll Account"); ?>

<?php $__env->startSection('content'); ?>
    <form method="post" action="<?php echo e(url('enroll-agreement')); ?>">
		<?php echo e(csrf_field()); ?>

                <div id="WelcomeMessageDiv" class="welcome-message">
                    <div class="LoginWelcomeLiteralDiv">
                        
<meta name="generator" content="HTML Tidy, see www.w3.org">


<font face="Arial" color="Red">Alert: Hidden registration form. To be used only by admins.<br>
</font>
<br/>
                    </div>
                </div>
            
        
        <div class="LoginClear"></div>
        <div class="LoginPadding10">
            <fieldset class="NoMargin AuthenticationLoginFieldset">
                <legend></legend>
                <div class="row">
                    <div class="six columns">
                        <strong>
                            <label for="ctl00_PageContent_Login1_IdTextBox" id="ctl00_PageContent_Login1_IdLabel" class="LoginTextBox">First&#32;Name:&#32;</label>
                        </strong>
                    </div>
                    <div class="six columns">
                        <input name="fname" type="text" size="30" id="ctl00_PageContent_Login1_IdTextBox" class="LoginIdTextBox" AutoComplete="off" ToggleTabIndex="true" />
                          
                    </div>
                </div>
				<div class="row">
                    <div class="six columns">
                        <strong>
                            <label for="ctl00_PageContent_Login1_IdTextBox" id="ctl00_PageContent_Login1_IdLabel" class="LoginTextBox">Last&#32;Name:&#32;</label>
                        </strong>
                    </div>
                    <div class="six columns">
                        <input name="lname" type="text" size="30" id="ctl00_PageContent_Login1_IdTextBox" class="LoginIdTextBox" AutoComplete="off" ToggleTabIndex="true" />
                          
                    </div>
                </div>
				<div class="row">
                    <div class="six columns">
                        <strong>
                            <label for="ctl00_PageContent_Login1_IdTextBox" id="ctl00_PageContent_Login1_IdLabel" class="LoginTextBox">Email&#32;Address:&#32;</label>
                        </strong>
                    </div>
                    <div class="six columns">
                        <input name="email" type="text" size="30" id="ctl00_PageContent_Login1_IdTextBox" class="LoginIdTextBox" AutoComplete="off" ToggleTabIndex="true" />
                          
                    </div>
                </div>
				<div class="row">
                    <div class="six columns">
                        <strong>
                            <label for="ctl00_PageContent_Login1_IdTextBox" id="ctl00_PageContent_Login1_IdLabel" class="LoginTextBox">Phone&#32;Number:&#32;</label>
                        </strong>
                    </div>
                    <div class="six columns">
                        <input name="phone" type="text" size="30" id="ctl00_PageContent_Login1_IdTextBox" class="LoginIdTextBox" AutoComplete="off" ToggleTabIndex="true" />
                          
                    </div>
                </div>
                <div class="row">
                    <div class="six columns">
                        <strong>
                            <label for="ctl00_PageContent_Login1_PasswordTextBox" id="ctl00_PageContent_Login1_PasswordLabel" class="LoginTextBox">Password: </label>
                        </strong>
                    </div>
                    <div class="six columns">
                        <input name="pass" type="password" size="30" id="ctl00_PageContent_Login1_PasswordTextBox" class="LoginPwdTextBox" AutoComplete="Off" ToggleTabIndex="true" />
                    </div>
                </div>
				<div class="row">
                    <div class="six columns">
                        <strong>
                            <label for="ctl00_PageContent_Login1_PasswordTextBox" id="ctl00_PageContent_Login1_PasswordLabel" class="LoginTextBox">Confirm Password: </label>
                        </strong>
                    </div>
                    <div class="six columns">
                        <input name="pass_confirmation" type="password" size="30" id="ctl00_PageContent_Login1_PasswordTextBox" class="LoginPwdTextBox" AutoComplete="Off" ToggleTabIndex="true" />
                    </div>
                </div>
            </fieldset>
        </div>

        <div class="button-containerADA LoginButtonContainerDiv">
            
            
            <input type="submit" name="ctl00$PageContent$Login1$LoginButton" value="Submit" id="ctl00_PageContent_Login1_LoginButton" class="ColorButton" ToggleTabIndex="true" />
             <a id="ctl00_PageContent_Login1_PasswordSelfResetLinkButton" class="LoginSelfResetLinkButton" ToggleTabIndex="true" title="Reset Password" href="<?php echo e(url('login')); ?>">Login</a>
        </div>
		</form>

        <div id="ctl00_PageContent_Login1_divPasswordResetLayout2" class="LoginCenter">
            
            
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('login_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/register.blade.php ENDPATH**/ ?>