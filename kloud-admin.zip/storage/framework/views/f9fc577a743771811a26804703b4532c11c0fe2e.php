<?php $__env->startSection('title',"View Deal"); ?>

<?php $__env->startSection('content'); ?>

        <!-- row -->
        <div class="row tm-content-row">
          <div class="tm-block-col tm-col-avatar">
            <div class="tm-bg-primary-dark tm-block tm-block-avatar">
              <h2 class="tm-block-title">Images</h2>
              <div class="tm-avatar-container">
                <img
                  src="img/lgg.png"
                  alt="<?php echo e($deal['name']); ?>"
                  class="tm-avatar img-fluid mb-4"
                />
                <a href="#" class="tm-avatar-delete-link">
                  <i class="far fa-trash-alt tm-product-delete-icon"></i>
                </a>
              </div>
            </div>
          </div>
          <div class="tm-block-col tm-col-account-settings">
            <div class="tm-bg-primary-dark tm-block tm-block-settings">
              <h2 class="tm-block-title">Account Settings</h2>
              <form action="<?php echo e(url('deal')); ?>" method="post" class="tm-signup-form row">
			     <?php echo e(csrf_field()); ?>


                <div class="form-group col-lg-6">
                  <label for="phone">Name</label>
                  <input
                    id="phone"
                    name="name"
					value="<?php echo e($deal['name']); ?>"
                    type="text"
					required
                    class="form-control validate"
                  />
                </div>
				<div class="form-group col-lg-6">
                  <label for="phone">SKU</label>
                  <input
                    id="phone"
                    name="sku"
					value="<?php echo e($deal['sku']); ?>"
                    type="text"
					readonly
                    class="form-control validate"
                  />
                </div>
                <div class="form-group col-lg-12">
                  <label for="phone">Description</label>
                 <textarea class="form-control validate" name='description' required><?php echo e($deal['data']['description']); ?></textarea>
                </div>
				<div class="form-group col-lg-6">
                  <label for="phone">Amount (&#8358;)</label>
                  <input
                    id="phone"
                    name="amount"
					value="<?php echo e($deal['data']['amount']); ?>"
                    type="number"
                    class="form-control validate"
                  />
                </div>
				<div class="form-group col-lg-6">
                  <label for="phone">Category</label>
                  <select
                    id="phone"
                    name="category"
                    class="form-control validate"
					>
					<option value="none">Select category</option>
					   <?php $__currentLoopData = $c; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php $ss = ($deal['category'] == $key) ? 'selected="selected"' : ''; ?>
                              <option value="<?php echo e($key); ?>" <?php echo e($ss); ?>><?php echo e($value); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
				<div class="form-group col-lg-4">
                  <label for="phone">Rating</label>
                 <span class="form-control">
                          	<?php for($u = 0; $u < $deal['rating']; $u++){ ?>
                            	<i class="far fa-star text-primary"></i>
                              <?php } ?>
                          </span>
                </div>
				<div class="form-group col-lg-4">
                  <label for="phone">Inventory status</label>
                  <select
                    id="phone"
                    name="in_stock"
                    class="form-control validate"
					>
					<option value="none">Select inventory status</option>
                              <?php 
                              $iss = ['yes' => 'In stock','new' => 'New!','no' => 'Out of Stock'];                           
                              foreach($iss as $key => $value){ 
                              	$ss = ($deal['data']['in_stock'] == $key) ? 'selected="selected"' : ''; 
                              ?>
                              <option value="<?=$key?>" <?=$ss?>><?=$value?></option>
                              <?php } ?>
                  </select>
                </div>
				<div class="form-group col-lg-4">
                  <label for="phone">Status</label>
                  <select
                    id="phone"
                    name="status"
                    class="form-control validate"
					>
					<option value="none">Select status</option>
                              <?php 
                              $suss = ['approved' => 'Approved','pending'=> "Pending",'rejected' => 'Rejected'];                           
                              foreach($suss as $key => $value){ 
                              	$ss = ($deal['status'] == $key) ? 'selected="selected"' : ''; 
                              ?>
                              <option value="<?=$key?>" <?=$ss?>><?=$value?></option>
                              <?php } ?>
                  </select>
                </div>
                <div class="form-group col-lg-12">
                  <button
                    type="submit"
                    class="btn btn-primary btn-block text-uppercase"
                  >
                   Submit
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\kloud-admin\resources\views/deal.blade.php ENDPATH**/ ?>