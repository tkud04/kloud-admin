<?php $__env->startSection('title',"Dashboard"); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('generic-banner',['title' => "Dashboard"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\kloud-new\resources\views/dashboard.blade.php ENDPATH**/ ?>