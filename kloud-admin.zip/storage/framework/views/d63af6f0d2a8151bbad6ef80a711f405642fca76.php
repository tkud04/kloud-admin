<div class="InfoMessage_container">
		<div class="InfoMessageTable AuthInfoMessageInfoMessageTable">
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="AuthInfoMessageTableRow">
					<span class="ErrorMessageLabel AuthInfoMessageTableCell">Information Message:</span>
                    <div>
    					<div class="ErrorMessageTD AuthInfoMessageTableCell">
					        <span id="ctl00_InfoMessage1_ErrorInfoMessageLabel" class="LoginError adaAlert"><?php echo e($error); ?></span>
					    </div>                    
                    </div>
	            </div><br>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>				
		</div>
	</div><?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/input-errors-2.blade.php ENDPATH**/ ?>