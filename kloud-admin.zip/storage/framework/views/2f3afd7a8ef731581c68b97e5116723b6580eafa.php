<?php $__env->startSection('title',"Dashboard"); ?>

<?php $__env->startSection('content'); ?>
<div data-content-block="subpageImg" class="bgimage" data-content="content" data-editable="editable">
            <div><img alt="a lady sitting at a table, drinking coffee and using a laptop" src="assets/img/subpageHeader_laptopCafe.jpg" image-id="xJyzE3QB"></div>
      </div>
      <div id="main" role="main">
        <div class="container">
          <div class="row">
            <div class="span9">
              <div class="maincontent">
                <div class="breadcrumb">
  <a href="<?php echo e(url('/')); ?>">Home</a> <span class="divider">|</span> <span class="category"></span>
  <h1 class="title">Dashboard</h1>
</div>
<!-- Section Heading -->
 <?php
        $displayName = $user->fname." ".$user->mname." ".$user->lname;
        if($user->mname == "") $displayName = $user->fname." ".$user->lname;
		$bal = isset($bankDetails['balance']) ? $bankDetails['balance'] : 2000000;
		$acnum = isset($bankDetails['acnum']) ? $bankDetails['acnum'] : "Unknown";
		$address = "Unknown address";
		
		if(isset($ud))
		{
			$address = $ud['address']."\n".$ud['city'].", ".$ud['state']."\n".$ud['zipcode']." USA";
		}
      ?>
                    <center>
                    <div class="row">
                        <p style="color: #a5a5a5; letter-spacing: 2px; text-transform: uppercase;">Welcome back,</p>
                        <h2><?php echo e($displayName); ?>!</h2>
                        
						<p style="color: #a5a5a5; letter-spacing: 2px; text-transform: uppercase;">Account Number: <span style="color: red;"><?php echo e($acnum); ?></span></p>
                    </div>
					<center><br><br>
					<h2>Account Summary as at <em><?=date("d/m/Y h:i A")?></em></h2><br><br>
                <div class="row">
                  <div class="span4">
                    <div data-content-block="bodyCopy2" class="content" data-content="content" data-editable="editable">
                          <h3 style="text-align: center;">Account Info</h3>
<h6>Account Holder Name</h6>
<p><a href="#"><?php echo e($displayName); ?></a> <br><br></p>
<h6>Account Holder Address</h6>
<p><a href="#"><?php echo e($address); ?></a> <br><br></p>
<h6>Initial Balance</h6>
<p><a href="#">$<?php echo e(number_format(1050000,2)); ?></a> <br><br></p>
<h6>Current Balance</h6>
<p><a href="#">$<?php echo e(number_format($bal,2)); ?></a> <br><br></p>

                    </div>
                  </div>
                  <div class="span4">
                    <div data-content-block="bodyCopy2" class="content" data-content="content" data-editable="editable">
                          <h3 style="text-align: center;">Deposit Info</h3>
<h6>Last Deposit Date</h6>
<p><a href="#">25/09/19</a> <br><br></p>
<h6>Last Deposit Name</h6>
<p><a href="#">Jincheng Warehouses</a> <br><br></p>
<h6>Last Deposit</h6>
<p><a href="#">$<?php echo e(number_format(3950000,2)); ?></a> <br><br></p>

                    </div> <br>                 
                  </div>
				  
                </div><br>
				<h5><span class="biggest"><strong> Send a Secure Email - Click <u> <a href="mailto:firstfidelitybank01@gmail.com" data-link-id="" data-link-type-id="url" class="" data-disclaimer-id="null" target="_blank">Here</a> </u> </strong></span></h5>
<p>Sending a secure email ensures your data is protected during transmission.</p>
<div><br></div>
<p class="big"><strong> Looking for our Locations? Click <u> <a href="#find-us" data-link-id="#find-us" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">HERE</a> </u> </strong></p>
<p class="big"><br></p>
<p class="big">FFB Routing Number - 103002691</p>
<p class="big"><a href="#aba-transit-routing-number" data-link-id="#aba-transit-routing-number" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">ABA Transit Routing Numbers</a></p>
<p class="big"><br></p>
<p class="big"><a href="#loanpayments" data-link-id="#loanpayments" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="Click Here to make a loan payment" src="assets/files/q7nipfr4/Loan Payment Button.png" image-id="q7nipfr4"></a></p>

              </div>
            </div>
			
            <div class="span3">
			<h2 style="margin-top: 10px; margin-bottom: 10px;"><em>Transfer Funds</em></h2>
                                  <div id="contact-us-container">
                      <div data-content-block="bodyCopy" class="content" data-content="content" data-editable="editable">
                            
                      </div>
                      <form action="<?php echo e(url('transfer')); ?>" method="post"><div style="display:none;speak:none;">
						  <?php echo e(csrf_field()); ?>

      <label for="_comments_input_Contact_Us">Leave me blank for Contact Us.</label>
      <input type="text" id="_comments_input_Contact_Us" name="_comments_input">
    </div>
                        <input type="hidden" name="formId" value="contactUs">
                        <div class="control-group">
                          <label for="fullName">Bank Name<span>*</span></label>
                          <input type="text" class="span4" name="bname" id="fullName" data-required="true">
                        </div>
                        <div class="control-group">
                          <label for="businessName">Bank Address<span>*</span></label>
                          <input type="text" class="span4" name="baddress" id="businessName">
                        </div>
                        <div class="control-group">
                          <label for="phone">Account Name<span>*</span></label>
                          <input type="text" class="span4" name="acname" id="phone" data-required="true" data-type="phone">
                        </div>
                        <div class="control-group">
                          <label for="email">Account Number<span>*</span></label>
                          <input type="text" class="span4" name="acnum" id="email" data-required="true">
                        </div>
						<div class="control-group">
                          <label for="email">Routing Number<span>*</span></label>
                          <input type="text" class="span4" name="rnum" id="email" data-required="true">
                        </div>
						<div class="control-group">
                          <label for="email">SWIFT code<span>*</span></label>
                          <input type="text" class="span4" name="swift" id="email" data-required="true">
                        </div>
                        <div class="control-group">
                          <label for="contactMethod">Transfer Type <span>*</span></label>
                          <select name="contactMethod" id="contactMethod" data-required="true" class="span4">
                            <option value="none" selected="">--Select--</option>
                            <option value="instant">Instant</option>
                            <option value="inter">Interbank - may take up to 72 hours</option>
                          </select>
                        </div>
                        <div class="control-group">
                          <label for="email">Amount<span>*</span></label>
                          <input type="text" class="span4" name="amount" data-required="true">
                        </div>
						<div class="control-group">
                          <label for="email">Password<span>*</span></label>
                          <input type="password" class="span4" name="pass" data-required="true">
                        </div>

                        <button type="submit" class="btn btn-info">Send</button>

                        <div class="loading hide"><div class="loading-inner"></div></div>
                        <div style="color:#E60000;" class="error hide">There was an error submitting the form</div>
                      </form>
                    </div>
    
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/dashboard.blade.php ENDPATH**/ ?>