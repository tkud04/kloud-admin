<?php $__env->startSection('title',"KloudPay"); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('generic-banner',['title' => "KloudPay"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


	<!-- kloudpay section -->
	<section class="top-letest-product-section">
		<div class="container">
			<div class="section-title">
				<h2>Shopping Made Easy!</h2>
			</div>
			<div class="row">
          <div class="col-lg-12 mx-auto text-center">
            <p>KloudPay is your online wallet where you have monetary value to spend on any product on the <strong class="text-primary">KloudTransact</strong> platform.</p>
            <br>
            <div class="row">
            	<div class="col-lg-4 col-md-6 col-sm-6">
              <div class="card text-center" style="">
         <div class="card-body">         
            <div class="text-primary">
            <h5 class="card-title"><i class="fa fa-shopping-cart fa-2x" aria-hidden="true"></i></h5>
            <p class="card-text">Buy Deals Easily</p>
            <a href="<?php echo e(url('top-deals')); ?>" class="btn btn-primary text-white">Buy Top Deals Now</a>
            </div>
         </div>
       </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="card text-center" style="">
         <div class="card-body">         
            <div class="text-warning">
            <h5 class="card-title"><i class="fa fa-money fa-2x" aria-hidden="true"></i></h5>
            <p class="card-text">Send Funds To Your Friends</p>
            <a href="<?php echo e(url('kloudpay-transfer')); ?>" class="btn btn-primary text-white">Transfer Funds</a>
            </div>
         </div>
       </div>
            </div>
            <div class="col-lg-4 col-md-6 col-sm-6">
              <div class="card text-center" style="">
         <div class="card-body">         
            <div class="text-primary">
            <h5 class="card-title"><i class="fa fa-hourglass fa-2x" aria-hidden="true"></i></h5>
            <p class="card-text">Bid on Auctions</p>
            <a href="<?php echo e(url('auctions')); ?>" class="btn btn-primary text-white">Bid Now</a>
            </div>
         </div>
       </div>
            </div>
            </div>
            <br>
            	<center><a href="<?php echo e(url('wallet')); ?>" class="site-btn sb-dark">Go to your KloudPay Wallet</a></center>
          </div>
        </div>
		</div>
	</section>
	<!-- kloudpay section end -->
	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\kloud-new\resources\views/kloudpay.blade.php ENDPATH**/ ?>