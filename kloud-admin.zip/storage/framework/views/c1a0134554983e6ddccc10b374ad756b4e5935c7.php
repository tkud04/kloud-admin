<?php
$user = null;
?>


<?php $__env->startSection('title',"Not Found"); ?>

<?php $__env->startSection('content'); ?>
  <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-header card-header-primary">
                  <h4 class="card-title">Page Not Found</h4>
                  <p class="card-category">Couldn't find what you're looking for :(</p>
                </div>
                <div class="card-body">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="">
                          <?php echo e($exception->getMessage()); ?>

                        </div>
                      </div>
                    </div>                    
                    
                </div>
              </div>
            </div>           
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\kloud-new\resources\views/errors/404.blade.php ENDPATH**/ ?>