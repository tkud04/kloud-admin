<?php $__env->startSection('title',"Users"); ?>

<?php $__env->startSection('content'); ?>

            <!-- row -->
            <div class="row tm-content-row">
			
			   <div class="col-12 tm-block-col">
                    <div class="tm-bg-primary-dark tm-block tm-block-taller tm-block-scroll">
                        <h2 class="tm-block-title">View users, user details or enable/disable users</h2>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">NAME</th>
                                    <th scope="col">PHONE</th>
                                    <th scope="col">EMAIL</th>                                    
                                    <th scope="col">ROLE</th>                                    
                                    <th scope="col">STATUS</th>                                    
                                    <th scope="col">ACTIONS</th>                                    
                                </tr>
                            </thead>
                            <tbody>
							  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><b><?php echo e($u['fname']." ".$u['lname']); ?></b></th>
                                    
                                    <td><b><?php echo e($u['phone']); ?></b></td>
                                    <td><b><?php echo e($u['email']); ?></b></td>
                                    <td><b><?php echo e($u['role']); ?></b></td>
                                    <td><b><?php echo e($u['status']); ?> </b></td>
                                    <td>
									<a href="<?php echo e(url('user').'?email='.$u['email']); ?>" class="tm-product-delete-link"><i class="far fa-eye tm-product-delete-icon"></i></a>
									</td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\kloud-admin\resources\views/users.blade.php ENDPATH**/ ?>