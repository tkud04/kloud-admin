<?php $__env->startSection('title',"About Us"); ?>

<?php $__env->startSection('content'); ?>
      <div data-content-block="subpageImg" class="bgimage" data-content="content" data-editable="editable">
            <div><img alt="a lady looking at her cell phone" src="/assets/files/subHead_mobile.jpg" image-id="HPpNWY07"></div>
      </div>
      <div id="main" role="main">
        <div class="container">
          <div class="row">
            <div class="span9">
              <div class="maincontent">
                <div class="breadcrumb">
  <a href="/">Home</a> <span class="divider">|</span> <span class="category"></span>
  <h1 class="title">About First Fidelity Bank</h1>
</div>

                <div data-content-block="bodyCopy" class="content" data-content="content" data-editable="editable">
                      <p style="text-align: center;"><iframe src="https://www.youtube.com/embed/chHS04fDdIo" width="640" height="360" frameborder="0" allowfullscreen="allowfullscreen"></iframe></p>
<p style="text-align: center;"><br></p>
<p class="MsoNormal medium" style="text-align: left;"><u> </u> <span class="big">Since the early 1920s, First Fidelity Bank has taken pride in its legacy as a family owned bank capable of the same sophisticated technology as the &quot;big banks&quot;. Headquartered in Oklahoma City, First Fidelity combines generations of banking experience with international investment knowledge in 29 locations across Oklahoma and Arizona. The loyal workforce amounts to a staff of over 400 people. Each employee is a valued member of the &quot;First Fidelity family&quot; and is dedicated to getting to know our clients on a first name basis. Because of this commitment, our clients have come to expect the best customer service. </span></p>
<p class="MsoNormal medium" style="text-align: left;"><span class="big"> First Fidelity Bank's leadership believes that giving back to its neighbors and communities is an important responsibility and are dedicated to hiring and maintaining quality employees who share that passion. Annually, FFB donates a total of over $500,000 to local charities and educational foundations. First Fidelity is proud to be a United Way Pacesetter, hosting an annual giving campaign that helps set the tone for the community. Click on the links below to learn more about the bank and a few of our local partnerships. </span></p>
<p class="MsoNormal medium" style="text-align: left;"><br></p>
<p class="MsoNormal biggest" style="text-align: left;"><a href="/assets/files/YutPX4Z0/Annual Report 2018.pdf" data-link-id="" data-link-type-id="file" class="" data-disclaimer-id="null" target="_blank" rel="noopener"><u>FFB Annual Report</u></a></p>
<p class="MsoNormal biggest" style="text-align: left;"><u><a href="/energy" data-link-id="/energy" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">OKC Energy FC Partnership</a></u></p>
<p class="MsoNormal biggest" style="text-align: left;"><a href="/payit4ward" data-link-id="/payit4ward" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><u>KFOR News Channel 4 - Pay It 4Ward Partnership</u></a></p>
<p class="MsoNormal biggest" style="text-align: left;"><a href="/awards" data-link-id="/awards" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><u>Awards</u></a></p>
                </div>
              </div>
            </div>
            <div class="span3">
              <div class="sidebar" role="complementary">
                <div class="desktop-olb-container">

                </div>
                <div data-content-block="subArea" class="subpage-space" data-content="content" data-editable="editable">
                      <p><a href="https://umnasg22.umonitor.com/uopen/welcome.do?auth=fe5438c6637c055a" data-link-id="" data-link-type-id="url" class="btn btn-default" data-disclaimer-id="null" target="_self">Open a Consumer Account</a></p>
<p><a href="https://umnasg22.umonitor.com/uopen/bizwelcome.do?auth=fe5438c6637c055a" data-link-id="" data-link-type-id="url" class="btn btn-default" data-disclaimer-id="null" target="_self">Open a Business Account</a></p>
<p><a href="https://ffb.mortgage-application.net/Default.aspx " data-link-id="" data-link-type-id="url" class="btn btn-default" data-disclaimer-id="null" target="_self">Apply for a Mortgage</a></p>
<p><a href="https://umnasg7.umonitor.com/consumerloan/uLoan/welcome.do?auth=af71be880c8cbf96" data-link-id="" data-link-type-id="url" class="btn btn-default" data-disclaimer-id="null" target="_self">APPLY FOR A LOAN</a></p>
<p><a href="/personal-credit-card" data-link-id="/personal-credit-card" data-link-type-id="page" class="btn btn-default" data-disclaimer-id="null" target="_self">Apply for a Credit Card</a></p>
<p style="text-align: center;"><strong> <span class="biggest">Services to make your online banking easier!</span> </strong></p>
<p style="text-align: center;"><a href="/bank/bill-pay" data-link-id="/bank/bill-pay" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Bill Pay</a></p>
<p style="text-align: center;"><a href="/bank/direct-line-24-telephone-banking" data-link-id="/bank/direct-line-24-telephone-banking" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">Telephone Banking</a></p>
<p style="text-align: center;"><a href="/bank/debit-card" data-link-id="/bank/debit-card" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">First Fidelity Debit Card</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/about.blade.php ENDPATH**/ ?>