<?php $__env->startSection('title',"Contact Us"); ?>

<?php $__env->startSection('content'); ?>
<div data-content-block="subpageImg" class="bgimage" data-content="content" data-editable="editable">
            <div><img alt="a lady sitting at a table, drinking coffee and using a laptop" src="assets/img/subpageHeader_laptopCafe.jpg" image-id="xJyzE3QB"></div>
      </div>
      <div id="main" role="main">
        <div class="container">
          <div class="row">
            <div class="span9">
              <div class="maincontent">
                <div class="breadcrumb">
  <a href="<?php echo e(url('/')); ?>">Home</a> <span class="divider">|</span> <span class="category"></span>
  <h1 class="title">Contact Us</h1>
</div>
                <div class="row">
                  <div class="span4">
                    <div id="contact-us-container">
                      <div data-content-block="bodyCopy" class="content" data-content="content" data-editable="editable">
                            <h2>Hello!</h2>
<p>Please fill out the form below and we'll be in touch soon! <strong> Do NOT </strong> enter personal information such as SSN or account numbers. Thanks!</p>
                      </div>
                      <form action="<?php echo e(url('contact')); ?>" method="post" data-validate="parsley"><div style="display:none;speak:none;">
      <label for="_comments_input_Contact_Us">Leave me blank for Contact Us.</label>
      <input type="text" id="_comments_input_Contact_Us" name="_comments_input">
    </div>
	<?php echo e(csrf_field()); ?>

                        <input type="hidden" name="formId" value="contactUs">
                        <div class="control-group">
                          <label for="fullName">Full Name<span>*</span></label>
                          <input type="text" class="span4" name="name" id="fullName" data-required="true">
                        </div>
                        <div class="control-group">
                          <label for="businessName">Business Name (if applicable)</label>
                          <input type="text" class="span4" name="bname" id="businessName">
                        </div>
                        <div class="control-group">
                          <label for="phone">Phone<span>*</span></label>
                          <input type="tel" class="span4" name="phone" id="phone" data-required="true" data-type="phone">
                        </div>
                        <div class="control-group">
                          <label for="email">Email<span>*</span></label>
                          <input type="email" class="span4" name="email" id="email" data-required="true">
                        </div>
                        <div class="control-group">
                          <label for="contactMethod">Best Method of Contact <span>*</span></label>
                          <select name="cmethod" id="contactMethod" data-required="true" class="span4">
                            <option value="" selected="">--Select--</option>
                            <option value="Phone">Phone</option>
                            <option value="Email">Email</option>
                          </select>
                        </div>                    
                     

                        <div class="control-group">
                          <label for="comments">Questions or Comments</label>
                          <textarea name="comments" id="comments" class="span4" rows="5" data-required="true"></textarea>
                        </div>

                        <button type="submit" class="btn btn-info">Send</button>

                        <div class="loading hide"><div class="loading-inner"></div></div>
                        <div style="color:#E60000;" class="error hide">There was an error submitting the form</div>
                      </form>
                    </div>
                    <div id="success">
                      <div class="content" data-content-block="successCopy" data-content="content" data-editable="editable">
                          <h5>Thank you for contacting us! We will be in touch with you soon.</h5>
                      </div>
                    </div>
                  </div>
                  <div class="span4">
                    <div data-content-block="bodyCopy2" class="content" data-content="content" data-editable="editable">
                          <h3 style="text-align: center;">Contact by Phone</h3>
<h6>Customer Service</h6>
<p><a href="tel:334-392-0218">334-392-0218</a> <strong> Nationwide </strong></p>
<div><br></div>
<div>
<h6>Customer Service Hours</h6>
<div>
<div><strong>M-F  7:30am - 9:00pm CT</strong></div>
<div><strong>Sat   8:00am - 5:00pm CT</strong></div>
<div><strong>Sun - Closed</strong></div>
<div><strong> </strong></div>
</div>
</div><br>
<h3 style="text-align: center;">Contact by E-mail</h3>
<p><strong> Customer Service</strong>: <a href="mailto:firstfidelitybank01@gmail.com">Send us an e-mail</a></p>
<div><br></div>
<h3 style="text-align: center;">Contact by Mail</h3>
<p><strong> James P. Boggs </strong></p>
<p><strong> First Fidelity Bank </strong></p>
<p>P.O. Box 30627 <br></p>
<p>Gulf Shores, AL 36542</p>
<div><br></div>
<p class="big"><strong> Looking for our Locations? Click <u> <a href="#find-us" data-link-id="#find-us" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">HERE</a> </u> </strong></p>
<p class="big"><br></p>
<p class="big">FFB Routing Number - 103002691</p>
<p class="big"><a href="#" data-link-id="#aba-transit-routing-number" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self">ABA Transit Routing Numbers</a></p>
<p class="big"><br></p>
<p class="big"><a href="#" data-link-id="#" data-link-type-id="page" class="" data-disclaimer-id="null" target="_self"><img alt="Click Here to make a loan payment" src="assets/files/q7nipfr4/Loan Payment Button.png" image-id="q7nipfr4"></a></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="span3">
              <div class="sidebar" role="complementary">
                <div class="desktop-olb-container">

                </div>
                <div data-content-block="subArea" class="subpage-space" data-content="content" data-editable="editable">
                      <div id="poster" data-campaign-id="b6a160f0-654f-11e6-a2c3-56847afe9799" data-ad-id="b9af56f0-7ac9-11e6-bee2-56847afe9799">
<div><br></div>
<div class="subImg">
<h1 style="text-align: center;"><a title="Auto Loans" href="#">Auto Center</a></h1>
<p><img alt="" src="assets/content/49qAteOH/41d60090-11ca-11e8-9058-02427c8671ff" image-id="41d60090-11ca-11e8-9058-02427c8671ff"></p>
</div>
<div class="subText">
<p><a title="Auto Loans" href="#">FFB has partnered with TrueCar to save you time and money on a new vehicle.</a><br></p>
<p><a title="Auto Loans" href="#">Learn More <span style="color: #222222; font-family: Menlo, monospace; font-size: 11px; line-height: normal; white-space: pre-wrap;">»</span></a></p>
</div>
<div><br></div>
</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/contact.blade.php ENDPATH**/ ?>