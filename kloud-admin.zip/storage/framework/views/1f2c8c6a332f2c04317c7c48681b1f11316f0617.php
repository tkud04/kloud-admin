  <?php
  $signal = $signals['okays'];
   $lbl = "InfoMessageLabel";
   $td = "InfoMessageTD";   
           
   if($val == "error"){
   	$signal = $signals['errors'];
   	$lbl = "ErrorMessageLabel";
    $td = "ErrorMessageTD";	
       $pop .= "-error";
   } 
  ?>  
<div class="InfoMessage_container">
		<div class="InfoMessageTable AuthInfoMessageInfoMessageTable">
                <div class="AuthInfoMessageTableRow">
					<span class="<?php echo e($lbl); ?> AuthInfoMessageTableCell">Information Message:</span>
                    <div>
    					<div class="<?php echo e($td); ?> AuthInfoMessageTableCell">
					        <span id="ctl00_InfoMessage1_ErrorInfoMessageLabel" class="LoginError adaAlert"><?php echo e($signal[$pop]); ?></span>
					    </div>                    
                    </div>
	            </div><br>			
		</div>
	</div><?php /**PATH C:\bkupp\lokl\repo\bank-olly\resources\views/session-status-2.blade.php ENDPATH**/ ?>