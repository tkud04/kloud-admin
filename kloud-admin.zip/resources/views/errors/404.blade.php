<h3>The resource you are looking for could not be found on this server. Redirecting you to the home page..</h3>
<script>window.location = "{{url('/')}}";</script>