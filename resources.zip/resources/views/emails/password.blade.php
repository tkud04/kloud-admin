<center><h3>Having trouble accessing your account? </h3></center>

<center>
<p><strong>Here is the link to reset your password: </strong>{{$ll}}</p><br>
<p>If you can't click the link above <strong>please copy and paste the following link to your browser: </strong>{{$ll}}</p><br>

<p style="font-color: red;"><em><strong>If you did not request to reset your password, kindly ignore this message.</strong></em></p><br>